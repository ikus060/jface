/*
 * Copyright (c) 2011, Patrik Dufresne. All rights reserved.
 * Patrik Dufresne PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.patrikdufresne.ui;

public interface IViewPartPage extends IViewPart {
	
	@Override
	public IPageSite getSite();
	
}
